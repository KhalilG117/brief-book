<?php 
	include "header.php";
	?>

<div style="margin: 0">
	<h4 style="padding-left: 150px ; padding-top: 35px ; color: #B219B0"> OUR BOOKS :</h4>
</div>
<div class="container" style="padding-top: 60px " >
<div class="card-deck">
  <div class="card"  style="border-color: black ; border-width: 5px; height: 360px">
    <div class="card-body">
      <h5 class="card-title"></h5>
      <p class="card-text"></p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
  <div class="card" style="border-color: black ; border-width: 5px;">
    <div class="card-body">
      <h5 class="card-title"></h5>
      <p class="card-text"></p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
  <div class="card" style="border-color: black ; border-width: 5px;">
    <div class="card-body">
      <h5 class="card-title"></h5>
      <p class="card-text"></p>
      <p class="card-text"><small class="text-muted"></small></p>
    </div>
  </div>
</div>
</div>